<?php
defined( 'ABSPATH' ) || exit;

global $theme_home;

$footer_page_id = ( $page = get_page_by_title( 'Footer Green', OBJECT, 'html_block' ) ) ? $page->ID : 0;
$home_page_id   = ( $page = get_page_by_title( 'Home Green' ) ) ? $page->ID : 0;

$mods                 = [];
$mods['accent_color'] = '#4bb050';
$mods['logo']         = 'https://parkofideas.com/antek/demo1/wp-content/uploads/2021/04/antek-0302896675.svg';

if ( $footer_page_id ) {
	$mods['footer_page'] = $footer_page_id;
}

$options = [];
if ( $home_page_id ) {
	$options['page_on_front'] = $home_page_id;
}

$theme_home = [
	'title'      => __( 'Green', 'ideapark-antek' ),
	'screenshot' => 'home-3.jpg',
	'url'        => 'https://parkofideas.com/antek/demo1/home-3/',
	'mods'       => $mods,
	'options'    => $options,
];